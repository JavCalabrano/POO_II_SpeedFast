package org.example.interfaces;

import org.example.model.Pedido;

public interface Cancelable {

    public void cancelar(Pedido pedido);

}
