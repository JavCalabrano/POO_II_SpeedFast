package org.example.interfaces;

import java.util.List;

public interface Rastreable {

    public List verHistorial();
}
